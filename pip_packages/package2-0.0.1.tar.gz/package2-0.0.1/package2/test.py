def test_package2():
    print("Hello from local package installed from archive")
